package org.vansama.hitcontinuously;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class HitContinuously extends JavaPlugin {

    @Override
    public void onEnable() {
        // 加载配置文件
        saveDefaultConfig(); // 确保配置文件存在并加载默认值
        FileConfiguration config = getConfig();

        // 创建HitListener监听器
        HitListener hitListener = new HitListener(this);
        getLogger().info("加载监听器成功");

        // 将监听器注册到Bukkit的事件系统中
        getServer().getPluginManager().registerEvents(hitListener, this);

        // 如果需要，可以在此处进行其他插件初始化操作
        getLogger().info(ChatColor.GREEN + "----------    -----------");
        getLogger().info(ChatColor.GREEN + "-                  -");
        getLogger().info(ChatColor.GREEN + "-                  -");
        getLogger().info(ChatColor.GREEN + "-                  -");
        getLogger().info(ChatColor.GREEN + "----------         -");
        getLogger().info(ChatColor.GREEN + "");
        getLogger().info(ChatColor.GREEN + "HitContinuously" + getDescription().getVersion() + " 版本 成功启动");
    }

    @Override
    public void onDisable() {
        // 插件禁用时的清理工作
        // 如果需要，可以在此处进行其他插件初始化操作
        getLogger().info(ChatColor.GREEN + "----------    -----------");
        getLogger().info(ChatColor.GREEN + "-                  -");
        getLogger().info(ChatColor.GREEN + "-                  -");
        getLogger().info(ChatColor.GREEN + "-                  -");
        getLogger().info(ChatColor.GREEN + "----------         -");
        getLogger().info(ChatColor.GREEN + "");
        getLogger().info(ChatColor.RED + "HitContinuously" + getDescription().getVersion() + " 版本 成功关闭");
    }
}