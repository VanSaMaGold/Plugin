package org.vansama.hitcontinuously;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class HitListener implements Listener {
    private final JavaPlugin plugin;
    private long attackCooldownMillis; // 攻击间隔时间，单位为毫秒
    private final java.util.HashMap<Player, Long> lastAttackTime = new java.util.HashMap<>();

    public HitListener(JavaPlugin plugin) {
        this.plugin = plugin;
        this.loadConfig();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    private void loadConfig() {
        FileConfiguration config = plugin.getConfig();
        // 获取攻击间隔配置，如果配置不存在或为0，则取消攻击间隔
        attackCooldownMillis = config.getInt("attack-cooldown", 3000); // 默认间隔3000毫秒，即3秒
    }

    @EventHandler
    public void onPlayerHitEntity(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        long currentTime = System.currentTimeMillis();

        // 检查是否设置了无间隔攻击
        if (attackCooldownMillis == 0) {
            // 允许玩家连续攻击
            event.setCancelled(false);
        } else {
            // 检查玩家上一次攻击时间是否已超过冷却时间
            Long lastAttack = lastAttackTime.get(player);
            if (lastAttack == null || (currentTime - lastAttack) >= attackCooldownMillis) {
                // 重置攻击时间
                lastAttackTime.put(player, currentTime);
                event.setCancelled(false); // 允许攻击
            } else {
                // 取消攻击，因为还在冷却时间内
                event.setCancelled(true);
            }
        }
    }
}